#include "player_threads.h"
#include "../critical_section/pitch.h"
#include <iostream>
#include <unistd.h>

using namespace std;

// ============================================================
//  HELPER: Human-readable labels
// ============================================================

const char* wicket_name(int wt) {
    switch (wt) {
        case BOWLED:  return "Bowled";
        case CAUGHT:  return "Caught";
        case RUN_OUT: return "Run Out";
        case LBW:     return "LBW";
        case STUMPED: return "Stumped";
        default:      return "None";
    }
}

const char* ball_type_name(int bt) {
    switch (bt) {
        case WIDE:     return "WIDE";
        case NO_BALL:  return "NO BALL";
        case FREE_HIT: return "FREE HIT";
        default:       return "normal";
    }
}

// ============================================================
//  PENDING EVENT
//
//  Written by the bowler while it holds pitch_mutex.
//  Read by the striker after waking on ball_delivered.
//  Protected by pitch_mutex — no additional lock required.
// ============================================================
static BallEvent pending_event;

// ============================================================
//  BOWLER THREAD
//
//  Lifecycle per ball:
//    1. Lock pitch_mutex  (enter critical section)
//    2. Call generate_event() — decides all outcomes up front
//    3. Store event in pending_event for batsman
//    4. Signal batsmen via ball_delivered
//    5. Wait on stroke_finished until striker is done
//    6. Log summary and unlock pitch_mutex
// ============================================================

void* bowler_thread(void* arg) {

    while (match_running) {

        // ── Enter pitch (critical section) ──────────────────
        pthread_mutex_lock(&pitch_mutex);

        if (!match_running) {
            pthread_mutex_unlock(&pitch_mutex);
            break;
        }

        // ── Generate all event outcomes for this delivery ────
        // Encapsulating outcome generation here (before signalling
        // the batsman) avoids any data race on rand() and keeps
        // all state mutation in one place.
        BallEvent ev = generate_event();
        pending_event = ev;

        pthread_mutex_lock(&print_mutex);
        cout << "\n======================================" << endl;
        if (ev.type != NORMAL)
            cout << "[Bowler] Delivering  [" << ball_type_name(ev.type) << "]" << endl;
        else
            cout << "[Bowler] Delivering  [Ball " << (balls_bowled + 1) << "]" << endl;
        pthread_mutex_unlock(&print_mutex);

        sleep(1);   // Simulate the bowler's run-up

        // ── Signal batsman: ball is on its way ───────────────
        // ball_ready = true  → batsman's while(!ball_ready) loop exits
        // stroke_done = false → bowler's while(!stroke_done) loop waits
        ball_ready  = true;
        stroke_done = false;
        pthread_cond_broadcast(&ball_delivered);  // Wake all batsmen

        // ── Wait for striker to complete the shot ────────────
        // The striker sets stroke_done = true and signals stroke_finished
        // before releasing pitch_mutex, so this wait is safe.
        while (match_running && !stroke_done) {
            pthread_cond_wait(&stroke_finished, &pitch_mutex);
        }

        if (!match_running) {
            pthread_mutex_unlock(&pitch_mutex);
            break;
        }

        pthread_mutex_lock(&print_mutex);
        cout << "[Bowler] Ball settled.  Score: " << global_score
             << "  |  Wickets: " << wickets_fallen
             << "  |  Balls: "   << balls_bowled << endl;
        cout << "======================================" << endl;
        pthread_mutex_unlock(&print_mutex);

        // ── Exit critical section ────────────────────────────
        pthread_mutex_unlock(&pitch_mutex);

        sleep(1);   // Brief pause between deliveries
    }

    return NULL;
}

// ============================================================
//  BATSMAN THREAD
//
//  Two batsmen share this function (id = 1 or 2).
//  Only the STRIKER (id == striker) processes the event.
//  The non-striker yields immediately so the striker can
//  re-acquire pitch_mutex and continue.
//
//  Inside the critical section (pitch_mutex held):
//    1. Read pending_event
//    2. Handle delivery type (WIDE / NO_BALL / FREE_HIT / NORMAL)
//    3. If ball_in_air → wake fielders (fielder_mutex)
//    4. Handle wicket
//    5. Handle runs + crease swaps
//    6. Increment balls_bowled for legal deliveries
//    7. Reset per-ball flags
//    8. Signal stroke_finished → unblocks bowler
// ============================================================

void* batsman_thread(void* arg) {
    int id = *(int*)arg;

    while (match_running) {

        // ── Wait for ball under pitch_mutex ─────────────────
        pthread_mutex_lock(&pitch_mutex);

        while (match_running && !ball_ready) {
            pthread_cond_wait(&ball_delivered, &pitch_mutex);
        }

        if (!match_running) {
            pthread_mutex_unlock(&pitch_mutex);
            break;
        }

        // ── Non-striker: release and yield ───────────────────
        // The non-striker has no action until the striker has played.
        // Release pitch_mutex so the striker can acquire it and process.
        if (id != striker) {
            pthread_mutex_unlock(&pitch_mutex);
            usleep(500000);  // Brief yield — prevents tight spin
            continue;
        }

        // ─────────────────────────────────────────────────────
        //  STRIKER: Full ball lifecycle inside critical section
        // ─────────────────────────────────────────────────────
        BallEvent ev = pending_event;

        pthread_mutex_lock(&print_mutex);
        cout << "[Batsman " << id << " (striker)] Facing delivery" << endl;
        pthread_mutex_unlock(&print_mutex);

        sleep(1);   // Simulate reading the ball and playing the shot

        // ── WIDE: penalty run, batsman does not play ─────────
        if (ev.type == WIDE) {
            pthread_mutex_lock(&print_mutex);
            cout << "  [Umpire] WIDE — +1 run (does not count as a ball)" << endl;
            pthread_mutex_unlock(&print_mutex);

            update_score(1);
            // WIDEs do NOT increment balls_bowled
            goto finish_ball;
        }

        // ── NO_BALL announcement ─────────────────────────────
        if (ev.type == NO_BALL) {
            pthread_mutex_lock(&print_mutex);
            cout << "  [Umpire] NO BALL — +1 penalty, next ball is FREE HIT" << endl;
            pthread_mutex_unlock(&print_mutex);
        }

        // ── FREE_HIT announcement ─────────────────────────────
        if (ev.type == FREE_HIT) {
            pthread_mutex_lock(&print_mutex);
            cout << "  [Umpire] FREE HIT — batsman safe from most dismissals" << endl;
            pthread_mutex_unlock(&print_mutex);
        }

        // ── Ball in air: wake fielders + keeper ──────────────
        // DESIGN: ball_in_air is the STATE that fielders poll.
        //         fielder_wake_cond is the EVENT that wakes them.
        //         We set state first, then broadcast — this ensures
        //         no fielder misses the wake-up (no lost wakeups).
        if (ev.ball_in_air) {
            pthread_mutex_lock(&print_mutex);
            cout << "  [Batsman " << id << "] Ball in the air! Fielders alert!" << endl;
            pthread_mutex_unlock(&print_mutex);

            pthread_mutex_lock(&fielder_mutex);
            ball_in_air = true;                       // Set STATE
            pthread_cond_broadcast(&fielder_wake_cond); // Broadcast EVENT
            pthread_mutex_unlock(&fielder_mutex);

            usleep(800000);  // Allow fielder threads time to react
        }

        // ── Boundary: 4 or 6 — fielders do not chase ─────────
        if (ev.boundary) {
            pthread_mutex_lock(&print_mutex);
            cout << "  [Batsman " << id << "] ";
            cout << (ev.runs == 6 ? "SIX! Over the ropes!" : "FOUR! Racing to the boundary!") << endl;
            pthread_mutex_unlock(&print_mutex);

            update_score(ev.runs);
            // No crease swaps for boundaries
            if (ev.type == NORMAL || ev.type == FREE_HIT)
                balls_bowled++;
            goto finish_ball;
        }

        // ── Wicket ────────────────────────────────────────────
        if (ev.wicket != NONE) {
            pthread_mutex_lock(&print_mutex);
            cout << "  [WICKET] Batsman " << id << " is OUT — "
                 << wicket_name(ev.wicket) << "!" << endl;
            pthread_mutex_unlock(&print_mutex);

            wickets_fallen++;

            // New batsman comes in (simplified: sequential IDs)
            int new_id = striker + 2;
            pthread_mutex_lock(&print_mutex);
            cout << "  [Innings] Batsman " << new_id << " comes to the crease." << endl;
            pthread_mutex_unlock(&print_mutex);

            striker = new_id;

            // Run-out may have scored partial runs before the wicket
            if (ev.wicket == RUN_OUT && ev.runs > 0)
                update_score(ev.runs);

            if (ev.type == NORMAL || ev.type == FREE_HIT)
                balls_bowled++;
            goto finish_ball;
        }

        // ── Runs ──────────────────────────────────────────────
        if (ev.runs > 0) {
            update_score(ev.runs);

            // Batsmen physically run — simulate crease swaps
            is_running = true;
            pthread_mutex_lock(&print_mutex);
            cout << "  [Running] Batsmen " << striker << " & " << non_striker
                 << " running — " << ev.runs << " run(s)" << endl;
            pthread_mutex_unlock(&print_mutex);

            for (int i = 0; i < ev.runs; i++) {
                usleep(400000);   // Time to complete one run
                // Each completed run swaps striker and non-striker
                int tmp     = striker;
                striker     = non_striker;
                non_striker = tmp;
                pthread_mutex_lock(&print_mutex);
                cout << "    Run " << (i + 1) << " completed — "
                     << "striker now: Batsman " << striker << endl;
                pthread_mutex_unlock(&print_mutex);
            }
            is_running = false;

        } else {
            pthread_mutex_lock(&print_mutex);
            cout << "  [Batsman " << id << "] Dot ball — no run" << endl;
            pthread_mutex_unlock(&print_mutex);
        }

        // Count legal deliveries (NO_BALL is NOT a legal delivery)
        if (ev.type == NORMAL || ev.type == FREE_HIT)
            balls_bowled++;

    finish_ball:
        // ── Reset per-ball flags ──────────────────────────────
        // IMPORTANT: ball_in_air is reset here (under pitch_mutex)
        // AFTER fielders have already been broadcast.  The fielder
        // threads clear their own wait loop based on ball_in_air
        // under fielder_mutex, so this reset does not cause a race.
        ball_in_air    = false;
        boundary       = false;
        is_running     = false;
        wicket_attempt = false;
        ball_ready     = false;
        stroke_done    = true;

        // ── Signal bowler: shot is done ───────────────────────
        pthread_cond_signal(&stroke_finished);
        pthread_mutex_unlock(&pitch_mutex);
    }

    return NULL;
}

// ============================================================
//  FIELDER THREAD
//
//  Sleep under fielder_mutex + fielder_wake_cond.
//  The wait condition is: while (!ball_in_air)
//    → STATE (ball_in_air) is checked in the loop
//    → EVENT (fielder_wake_cond) is what wakes the thread
//  This separation prevents lost wakeups.
// ============================================================

void* fielder_thread(void* arg) {
    int id = *(int*)arg;

    while (match_running) {

        // ── Sleep until ball is in the air ───────────────────
        pthread_mutex_lock(&fielder_mutex);

        // CORRECT pattern: check STATE inside the wait loop
        // so spurious wakeups and lost wakeups are both handled.
        while (match_running && !ball_in_air) {
            pthread_cond_wait(&fielder_wake_cond, &fielder_mutex);
        }

        if (!match_running) {
            pthread_mutex_unlock(&fielder_mutex);
            break;
        }

        // Mark that we are actively fielding (resets to false after)
        wicket_attempt = true;

        pthread_mutex_lock(&print_mutex);
        cout << "  [Fielder " << id << "] Reacting — ball in the air!" << endl;
        pthread_mutex_unlock(&print_mutex);

        pthread_mutex_unlock(&fielder_mutex);

        // ── Simulate fielding action ──────────────────────────
        usleep(300000);   // Reaction + sprint time

        int outcome = rand() % 100;
        if (outcome < 10) {
            // Clean catch
            pthread_mutex_lock(&print_mutex);
            cout << "  [Fielder " << id << "] CATCH — taken cleanly!" << endl;
            pthread_mutex_unlock(&print_mutex);
        } else if (outcome < 20) {
            // Dropped catch
            pthread_mutex_lock(&print_mutex);
            cout << "  [Fielder " << id << "] CATCH — put down! (chance missed)" << endl;
            pthread_mutex_unlock(&print_mutex);
        } else if (outcome < 40 && is_running) {
            // Chase + run-out attempt
            pthread_mutex_lock(&print_mutex);
            cout << "  [Fielder " << id << "] Chasing — backing up for run-out" << endl;
            pthread_mutex_unlock(&print_mutex);
        } else {
            // Routine stop
            pthread_mutex_lock(&print_mutex);
            cout << "  [Fielder " << id << "] Ball stopped at " << (id * 3) << " metres" << endl;
            pthread_mutex_unlock(&print_mutex);
        }

        pthread_mutex_lock(&print_mutex);
        cout << "  [Fielder " << id << "] Back to position" << endl;
        pthread_mutex_unlock(&print_mutex);
    }

    return NULL;
}

// ============================================================
//  WICKET KEEPER THREAD
//
//  Same wait pattern as fielder (uses fielder_mutex / fielder_wake_cond).
//  Additional responsibilities:
//    • Stumping  — when batsman is out of crease and ball is gloved
//    • Catch behind the wicket
//    • Run-out at keeper's end
// ============================================================

void* wicket_keeper_thread(void* arg) {

    while (match_running) {

        // ── Wait for ball_in_air ──────────────────────────────
        pthread_mutex_lock(&fielder_mutex);

        while (match_running && !ball_in_air) {
            pthread_cond_wait(&fielder_wake_cond, &fielder_mutex);
        }

        if (!match_running) {
            pthread_mutex_unlock(&fielder_mutex);
            break;
        }

        pthread_mutex_lock(&print_mutex);
        cout << "  [Keeper] Ball incoming — gloves ready!" << endl;
        pthread_mutex_unlock(&print_mutex);

        pthread_mutex_unlock(&fielder_mutex);

        usleep(200000);   // Keeper is usually in line with the ball

        // ── Decide keeper's specific action ──────────────────
        int action = rand() % 100;

        if (action < 15) {
            // Stumping attempt (valid when batsman is outside crease)
            pthread_mutex_lock(&print_mutex);
            cout << "  [Keeper] STUMPING attempt — bails off!" << endl;
            pthread_mutex_unlock(&print_mutex);

        } else if (action < 30) {
            // Catch behind the wicket
            pthread_mutex_lock(&print_mutex);
            cout << "  [Keeper] Catch behind the wicket — "
                 << ((action < 22) ? "taken!" : "grassed!") << endl;
            pthread_mutex_unlock(&print_mutex);

        } else if (action < 45 && is_running) {
            // Run-out at keeper's end
            pthread_mutex_lock(&print_mutex);
            cout << "  [Keeper] RUN-OUT attempt at the stumps!" << endl;
            pthread_mutex_unlock(&print_mutex);

        } else {
            // Routine collect
            pthread_mutex_lock(&print_mutex);
            cout << "  [Keeper] Routine collect behind the stumps" << endl;
            pthread_mutex_unlock(&print_mutex);
        }

        pthread_mutex_lock(&print_mutex);
        cout << "  [Keeper] Back in position" << endl;
        pthread_mutex_unlock(&print_mutex);
    }

    return NULL;
}
