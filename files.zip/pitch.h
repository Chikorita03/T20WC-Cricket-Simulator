#pragma once
#include <pthread.h>

// ============================================================
//  ENUMERATIONS
// ============================================================

// Types of deliveries a bowler can send
enum BallType {
    NORMAL,    // Standard delivery — counts as a ball
    WIDE,      // +1 run, does NOT count as a ball, no batsman shot
    NO_BALL,   // +1 run, does NOT count as a ball, next ball is FREE_HIT
    FREE_HIT   // Counts as a ball; batsman can ONLY be out via RUN_OUT
};

// Ways a batsman can be dismissed
enum WicketType {
    NONE,     // No dismissal
    BOWLED,   // Ball hits stumps directly
    CAUGHT,   // Ball caught by fielder / keeper before bouncing
    RUN_OUT,  // Batsman fails to complete a run in time
    LBW,      // Leg Before Wicket
    STUMPED   // Keeper removes bails while batsman is out of crease
};

// ============================================================
//  BALL EVENT STRUCTURE
// ============================================================

// Complete description of what happened on a single delivery
struct BallEvent {
    BallType   type;         // Delivery type
    int        runs;         // Runs scored (including extras)
    WicketType wicket;       // Dismissal type (NONE if no wicket)
    bool       ball_in_air;  // True → wake fielders + keeper
    bool       boundary;     // True → 4 or 6 (fielders NOT involved in fielding)
};

// ============================================================
//  MUTEXES
// ============================================================

extern pthread_mutex_t pitch_mutex;    // Critical section — one ball at a time
extern pthread_mutex_t print_mutex;    // Serialises console output
extern pthread_mutex_t score_mutex;    // Guards global_score
extern pthread_mutex_t fielder_mutex;  // Guards fielder condition variable

// ============================================================
//  CONDITION VARIABLES
// ============================================================

extern pthread_cond_t ball_delivered;    // Bowler → Batsman: "ball is on its way"
extern pthread_cond_t stroke_finished;   // Batsman → Bowler: "shot played, ball settled"
extern pthread_cond_t fielder_wake_cond; // Batsman → Fielders/Keeper: "ball is in air"

// ============================================================
//  SHARED FLAGS  (all guarded by pitch_mutex unless noted)
// ============================================================

extern bool ball_ready;       // Bowler has delivered; batsman may play
extern bool stroke_done;      // Batsman has finished; bowler may re-enter

extern bool ball_in_air;      // Ball is airborne — fielders / keeper must react
                              // (guarded by fielder_mutex)
extern bool boundary;         // It's a 4 or 6 — no fielder chase required
extern bool is_running;       // Batsmen are running between creases
extern bool wicket_attempt;   // A fielder is attempting a catch / run-out

// ============================================================
//  MATCH STATE
// ============================================================

extern int  global_score;       // Total runs scored so far
extern int  striker;            // ID of the batsman currently on strike
extern int  non_striker;        // ID of the batsman at the non-striker end
extern bool next_is_free_hit;   // Set after a NO_BALL — next delivery is FREE_HIT
extern int  balls_bowled;       // Count of legal deliveries (NORMAL + FREE_HIT)
extern int  wickets_fallen;     // How many wickets have fallen this innings
extern bool match_running;      // Global stop flag — set false to end simulation

// ============================================================
//  FUNCTION DECLARATIONS
// ============================================================

void      init_pitch();
void      destroy_pitch();
void      update_score(int runs);
void      stop_match();
BallEvent generate_event();   // Replaces old generate_runs()
