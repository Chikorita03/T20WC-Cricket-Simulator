#include "pitch.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// ============================================================
//  MUTEX / CONDITION VARIABLE DEFINITIONS
// ============================================================

pthread_mutex_t pitch_mutex;
pthread_mutex_t print_mutex;
pthread_mutex_t score_mutex;
pthread_mutex_t fielder_mutex;   // Separate mutex so fielders never block the pitch

pthread_cond_t ball_delivered;    // Bowler  → Batsman
pthread_cond_t stroke_finished;   // Batsman → Bowler
pthread_cond_t fielder_wake_cond; // Batsman → Fielders / Keeper

// ============================================================
//  SHARED FLAGS
// ============================================================

bool ball_ready     = false;
bool stroke_done    = true;
bool ball_in_air    = false;  // STATE flag — guarded by fielder_mutex
bool boundary       = false;
bool is_running     = false;
bool wicket_attempt = false;

// ============================================================
//  MATCH STATE
// ============================================================

int  global_score     = 0;
int  striker          = 1;     // Batsman 1 starts on strike
int  non_striker      = 2;     // Batsman 2 at non-striker end
bool next_is_free_hit = false;
int  balls_bowled     = 0;
int  wickets_fallen   = 0;
bool match_running    = true;

// ============================================================
//  INIT / DESTROY
// ============================================================

void init_pitch() {
    srand((unsigned int)time(NULL));

    pthread_mutex_init(&pitch_mutex,   NULL);
    pthread_mutex_init(&print_mutex,   NULL);
    pthread_mutex_init(&score_mutex,   NULL);
    pthread_mutex_init(&fielder_mutex, NULL);

    pthread_cond_init(&ball_delivered,    NULL);
    pthread_cond_init(&stroke_finished,   NULL);
    pthread_cond_init(&fielder_wake_cond, NULL);
}

void destroy_pitch() {
    pthread_mutex_destroy(&pitch_mutex);
    pthread_mutex_destroy(&print_mutex);
    pthread_mutex_destroy(&score_mutex);
    pthread_mutex_destroy(&fielder_mutex);

    pthread_cond_destroy(&ball_delivered);
    pthread_cond_destroy(&stroke_finished);
    pthread_cond_destroy(&fielder_wake_cond);
}

// ============================================================
//  SCORE UPDATE  (atomic w.r.t. score_mutex)
// ============================================================

void update_score(int runs) {
    int new_score;

    pthread_mutex_lock(&score_mutex);
    global_score += runs;
    new_score = global_score;
    pthread_mutex_unlock(&score_mutex);

    pthread_mutex_lock(&print_mutex);
    cout << "  [Score] +" << runs << " run(s)  →  Total: " << new_score << endl;
    pthread_mutex_unlock(&print_mutex);
}

// ============================================================
//  STOP MATCH  (broadcasts to all waiting threads to unblock them)
// ============================================================

void stop_match() {
    // Unblock anything waiting on pitch condition variables
    pthread_mutex_lock(&pitch_mutex);
    ball_ready  = true;
    stroke_done = true;
    pthread_cond_broadcast(&ball_delivered);
    pthread_cond_broadcast(&stroke_finished);
    pthread_mutex_unlock(&pitch_mutex);

    // Unblock anything waiting on the fielder condition variable
    pthread_mutex_lock(&fielder_mutex);
    ball_in_air = false;
    pthread_cond_broadcast(&fielder_wake_cond);
    pthread_mutex_unlock(&fielder_mutex);
}

// ============================================================
//  BALL EVENT GENERATOR  (replaces old generate_runs())
//
//  KEY DESIGN: This function decides EVERYTHING about a delivery
//  (ball type, runs, wicket, flags) in one place, keeping the
//  rest of the system event-driven rather than state-polling.
// ============================================================

BallEvent generate_event() {
    BallEvent ev;
    ev.runs        = 0;
    ev.wicket      = NONE;
    ev.ball_in_air = false;
    ev.boundary    = false;

    // ── 1. Determine delivery type ─────────────────────────
    if (next_is_free_hit) {
        ev.type          = FREE_HIT;
        next_is_free_hit = false;  // Consume the free-hit flag
    } else {
        int t = rand() % 100;
        if      (t < 70) ev.type = NORMAL;
        else if (t < 83) ev.type = WIDE;
        else             ev.type = NO_BALL;
    }

    // ── 2. Apply delivery-type rules ──────────────────────
    switch (ev.type) {

        // WIDE: penalty run only, no shot played, no ball count
        case WIDE:
            ev.runs = 1;
            return ev;   // Early return: fielders are NOT involved

        // NO_BALL: penalty run + batsman still hits the ball
        // Next delivery is automatically a FREE_HIT
        case NO_BALL:
            ev.runs          = 1;     // Penalty run
            next_is_free_hit = true;  // Trigger free-hit for next legal ball
            {
                // Batsman may score additional runs off a no-ball
                int r = rand() % 100;
                if      (r < 30) { /* no extra runs */ }
                else if (r < 55) ev.runs += 1;
                else if (r < 70) ev.runs += 2;
                else if (r < 80) ev.runs += 3;
                else if (r < 95) { ev.runs += 4; ev.boundary = true; }
                else             { ev.runs += 6; ev.boundary = true; }
            }
            // Ball is in the air for fielders if batsman hit it but no boundary
            if (!ev.boundary && ev.runs > 1)
                ev.ball_in_air = true;
            return ev;

        // NORMAL / FREE_HIT: full cricket logic below
        case NORMAL:
        case FREE_HIT:
        default:
            break;
    }

    // ── 3. Determine runs (for NORMAL / FREE_HIT) ─────────
    int r = rand() % 100;
    if      (r < 30) ev.runs = 0;
    else if (r < 55) ev.runs = 1;
    else if (r < 70) ev.runs = 2;
    else if (r < 80) ev.runs = 3;
    else if (r < 95) { ev.runs = 4; ev.boundary = true; }
    else             { ev.runs = 6; ev.boundary = true; }

    // Ball goes to fielders when it is NOT a boundary
    // (fielders chase for run-out or diving stop)
    if (!ev.boundary)
        ev.ball_in_air = true;

    // ── 4. Determine wicket ────────────────────────────────
    // FREE_HIT: batsman can ONLY be run out
    if (ev.type == FREE_HIT) {
        if (!ev.boundary && (rand() % 100 < 5)) {
            ev.wicket      = RUN_OUT;
            ev.ball_in_air = true;
        }
        return ev;
    }

    // NORMAL: ~18% wicket probability (only when it's not a boundary)
    if (!ev.boundary) {
        int w = rand() % 100;
        if (w < 18) {
            int wt = rand() % 5;
            switch (wt) {
                // ball_in_air = false: no fielder action needed
                case 0: ev.wicket = BOWLED;  ev.ball_in_air = false; break;
                case 3: ev.wicket = LBW;     ev.ball_in_air = false; break;
                // ball_in_air = true: fielder / keeper must react
                case 1: ev.wicket = CAUGHT;  ev.ball_in_air = true;  break;
                case 2: ev.wicket = RUN_OUT; ev.ball_in_air = true;  break;
                case 4: ev.wicket = STUMPED; ev.ball_in_air = true;  break;
            }
            // Most dismissals score 0 runs; run-out may have partial credit
            if (ev.wicket != RUN_OUT)
                ev.runs = 0;
        }
    }

    return ev;
}
